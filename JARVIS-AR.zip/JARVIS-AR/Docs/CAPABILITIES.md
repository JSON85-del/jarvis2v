# Honest capability matrix

| Feature | iPhone implementation | Notes |
| --- | --- | --- |
| Live camera + world AR | ARKit `ARWorldTrackingConfiguration` + RealityKit | Requires physical device |
| Plane detection | Horizontal + vertical planes | Better with LiDAR |
| Scene mesh / occlusion | `sceneReconstruction = .mesh` when supported | Pro / LiDAR |
| Hand joints | Vision `VNDetectHumanHandPoseRequest` | 2D image space, unprojected |
| Full 3D hand skeleton | Not on iPhone ARKit | visionOS `HandTrackingProvider` later |
| Pinch / point / grab | Geometric joint tests + temporal evidence | Degrades in low light / occlusion |
| Wake word always-on | Not a first-class iOS API | Mic button + post-speech “JARVIS …” filter |
| Object class labels | `VNClassifyImageRequest` | Generic ImageNet-style classes; not retail SKU IDs |
| OCR | `VNRecognizeTextRequest` | Latin text; lighting dependent |
| Product SKU / stock | Backend `ProductCatalog` | Sample rows marked; live MHM via adapter |
| Persistent world maps | Session anchors implemented; `ARWorldMap` save optional | Not claimed as permanent without user save |
| Projecting light into air | Impossible on iPhone | HUD is screen-space + world-anchored entities |
| Moving physical objects | Impossible | Only virtual entities move |
