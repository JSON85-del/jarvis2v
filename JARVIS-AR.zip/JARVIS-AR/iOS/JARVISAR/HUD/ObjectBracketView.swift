import SwiftUI

struct ObjectBracketView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        if let label = app.objects.primaryLabel, app.mode == .scan || app.mode == .product || app.mode == .mhm {
            VStack(spacing: 6) {
                RoundedRectangle(cornerRadius: 2)
                    .stroke(app.objects.isUncertain ? HUDTheme.warn : HUDTheme.cyan, lineWidth: 0.8)
                    .frame(width: 210, height: 86)
                    .overlay(alignment: .topLeading) {
                        Text(label.uppercased())
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .foregroundStyle(HUDTheme.cyan)
                            .padding(8)
                    }
                Text(app.objects.confidenceText.uppercased())
                    .font(.system(size: 9, weight: .semibold, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.7))
            }
            .allowsHitTesting(false)
        }
    }
}
