import SwiftUI

struct HUDOverlayView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        GeometryReader { geo in
            ZStack {
                ScanChrome()
                    .allowsHitTesting(false)
                VStack {
                    topBar
                    Spacer()
                    if let panel = app.hud.infoPanel {
                        InfoCard(model: panel)
                            .padding(.horizontal, 20)
                            .padding(.bottom, 8)
                    }
                    bottomBar
                }
                .padding(.top, 8)
                .padding(.bottom, 12)

                if app.hud.radialOpen {
                    RadialMenuView { item in
                        app.interaction.handle(
                            event: GestureEvent(kind: .pinch, screenPoint: CGPoint(x: geo.size.width / 2, y: geo.size.height / 2)),
                            state: app
                        )
                        selectRadial(item)
                    }
                }

                if let cursor = app.hud.cursor {
                    SpatialCursor(label: app.hud.hoverLabel)
                        .position(cursor)
                        .allowsHitTesting(false)
                }

                HandSkeletonOverlay(hands: app.hands.hands)
                    .allowsHitTesting(false)
                ObjectBracketView()
                    .position(x: geo.size.width / 2, y: geo.size.height * 0.38)
            }
        }
    }

    private var topBar: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text("JARVIS")
                    .font(.system(size: 13, weight: .semibold, design: .monospaced))
                    .foregroundStyle(HUDTheme.cyan)
                Text(app.hud.grokStatus == .connected ? "ONLINE" : app.hud.grokStatus.rawValue)
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(app.hud.grokStatus == .connected ? HUDTheme.cyan : HUDTheme.warn)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 3) {
                StatusChip(title: "VISION", value: app.hud.visionStatus)
                StatusChip(title: "HAND", value: app.hands.statusText)
                StatusChip(title: "AR", value: app.ar.trackingHint == nil && app.ar.isRunning ? "TRACKING" : (app.ar.trackingHint ?? "OFFLINE"))
                StatusChip(title: "GROK", value: app.hud.grokStatus.rawValue, warn: app.hud.grokStatus != .connected)
            }
        }
        .padding(.horizontal, 16)
    }

    private var bottomBar: some View {
        VStack(spacing: 8) {
            if let hint = app.ar.trackingHint {
                Text(hint.uppercased())
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(HUDTheme.warn)
            }
            HStack(spacing: 14) {
                Button {
                    app.showSettings = true
                } label: {
                    Text("SYS")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                        .background(HUDTheme.glass)
                        .overlay(RoundedRectangle(cornerRadius: 6).stroke(HUDTheme.cyan.opacity(0.45), lineWidth: 0.6))
                }
                Spacer()
                VoiceOrb()
                Spacer()
                Text(app.mode.title)
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundStyle(HUDTheme.cyan)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(HUDTheme.glass)
            }
            .padding(.horizontal, 16)
            if !app.lastAssistantLine.isEmpty {
                Text(app.lastAssistantLine)
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.9))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
                    .lineLimit(3)
            }
        }
    }

    private func selectRadial(_ item: String) {
        switch item {
        case "SCAN": app.setMode(.scan); app.commands.execute(JarvisCommand(intent: .scanObject, target: nil, direction: nil, magnitude: nil, mode: nil, query: nil, objectType: nil))
        case "SEARCH": app.commands.execute(JarvisCommand(intent: .search, target: nil, direction: nil, magnitude: nil, mode: nil, query: nil, objectType: nil))
        case "MAP": app.setMode(.navigation)
        case "SYSTEM": app.setMode(.system); app.showSettings = true
        case "MEMORY": app.commands.execute(JarvisCommand(intent: .remember, target: nil, direction: nil, magnitude: nil, mode: nil, query: nil, objectType: nil))
        default: break
        }
        app.hud.radialOpen = false
    }
}

enum HUDTheme {
    static let cyan = Color(red: 0.35, green: 0.92, blue: 1.0)
    static let warn = Color(red: 1.0, green: 0.45, blue: 0.22)
    static let glass = Color.black.opacity(0.28)
}
