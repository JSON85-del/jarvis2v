import SwiftUI

struct StatusChip: View {
    var title: String
    var value: String
    var warn: Bool = false

    var body: some View {
        HStack(spacing: 6) {
            Text(title)
                .foregroundStyle(.white.opacity(0.45))
            Text(value)
                .foregroundStyle(warn ? HUDTheme.warn : HUDTheme.cyan)
        }
        .font(.system(size: 9, weight: .semibold, design: .monospaced))
    }
}

struct ScanChrome: View {
    var body: some View {
        GeometryReader { geo in
            let inset: CGFloat = 28
            Path { p in
                let r = CGRect(x: inset, y: inset + 18, width: geo.size.width - inset * 2, height: geo.size.height - inset * 2 - 36)
                let len: CGFloat = 22
                p.move(to: CGPoint(x: r.minX, y: r.minY + len))
                p.addLine(to: CGPoint(x: r.minX, y: r.minY))
                p.addLine(to: CGPoint(x: r.minX + len, y: r.minY))
                p.move(to: CGPoint(x: r.maxX - len, y: r.minY))
                p.addLine(to: CGPoint(x: r.maxX, y: r.minY))
                p.addLine(to: CGPoint(x: r.maxX, y: r.minY + len))
                p.move(to: CGPoint(x: r.minX, y: r.maxY - len))
                p.addLine(to: CGPoint(x: r.minX, y: r.maxY))
                p.addLine(to: CGPoint(x: r.minX + len, y: r.maxY))
                p.move(to: CGPoint(x: r.maxX - len, y: r.maxY))
                p.addLine(to: CGPoint(x: r.maxX, y: r.maxY))
                p.addLine(to: CGPoint(x: r.maxX, y: r.maxY - len))
            }
            .stroke(HUDTheme.cyan.opacity(0.35), lineWidth: 1)
        }
    }
}

struct SpatialCursor: View {
    var label: String?
    var body: some View {
        VStack(spacing: 4) {
            Circle()
                .stroke(HUDTheme.cyan, lineWidth: 1.2)
                .frame(width: 18, height: 18)
                .overlay(Circle().fill(HUDTheme.cyan.opacity(0.35)).frame(width: 4, height: 4))
            if let label {
                Text(label.uppercased())
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .padding(.horizontal, 6)
                    .padding(.vertical, 3)
                    .background(HUDTheme.glass)
                    .overlay(RoundedRectangle(cornerRadius: 3).stroke(HUDTheme.cyan.opacity(0.5), lineWidth: 0.6))
                    .foregroundStyle(HUDTheme.cyan)
            }
        }
    }
}

struct InfoCard: View {
    var model: InfoPanelModel
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(model.uncertain ? "IDENTIFICATION UNCERTAIN" : "OBJECT LOCK")
                .font(.system(size: 9, weight: .bold, design: .monospaced))
                .foregroundStyle(model.uncertain ? HUDTheme.warn : HUDTheme.cyan)
            Text(model.title)
                .font(.system(size: 18, weight: .semibold, design: .rounded))
            Text(model.subtitle)
                .font(.system(size: 11, design: .monospaced))
                .foregroundStyle(.white.opacity(0.7))
            ForEach(model.body, id: \.self) { line in
                Text(line)
                    .font(.system(size: 12))
                    .foregroundStyle(.white.opacity(0.86))
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial.opacity(0.55))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(HUDTheme.cyan.opacity(0.45), lineWidth: 0.8))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

struct VoiceOrb: View {
    @EnvironmentObject var app: AppState
    var body: some View {
        Button {
            app.voice.interruptSpeech()
            app.voice.toggleListen()
            app.isListening = app.voice.isListening
            app.hud.aiState = app.voice.isListening ? .listening : .idle
        } label: {
            ZStack {
                Circle()
                    .stroke(HUDTheme.cyan.opacity(0.5), lineWidth: 1)
                    .frame(width: 64, height: 64)
                if app.voice.isListening {
                    WaveformView(level: app.voice.level)
                        .frame(width: 46, height: 22)
                } else {
                    Text("JARVIS")
                        .font(.system(size: 9, weight: .bold, design: .monospaced))
                        .foregroundStyle(HUDTheme.cyan)
                }
            }
        }
        .accessibilityLabel("Microphone")
    }
}

struct WaveformView: View {
    var level: Float
    var body: some View {
        HStack(alignment: .center, spacing: 3) {
            ForEach(0..<5, id: \.self) { i in
                Capsule()
                    .fill(HUDTheme.cyan)
                    .frame(width: 3, height: 6 + CGFloat(level) * CGFloat(8 + i * 3))
            }
        }
    }
}

struct RadialMenuView: View {
    var onPick: (String) -> Void
    private let items = ["SCAN", "SEARCH", "MAP", "SYSTEM", "MEMORY"]
    var body: some View {
        ZStack {
            Circle()
                .stroke(HUDTheme.cyan.opacity(0.35), lineWidth: 0.8)
                .frame(width: 220, height: 220)
            ForEach(Array(items.enumerated()), id: \.offset) { idx, item in
                let angle = Double(idx) / Double(items.count) * 360.0 - 90
                Button(item) { onPick(item) }
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundStyle(HUDTheme.cyan)
                    .padding(8)
                    .background(HUDTheme.glass)
                    .clipShape(RoundedRectangle(cornerRadius: 4))
                    .offset(x: 96 * cos(angle * .pi / 180), y: 96 * sin(angle * .pi / 180))
            }
        }
    }
}

struct HandSkeletonOverlay: View {
    var hands: [TrackedHand]
    var body: some View {
        Canvas { ctx, _ in
            for hand in hands where !hand.isLost {
                for joint in hand.joints.values {
                    let r = CGRect(x: joint.screenPoint.x - 2.5, y: joint.screenPoint.y - 2.5, width: 5, height: 5)
                    ctx.fill(Path(ellipseIn: r), with: .color(HUDTheme.cyan.opacity(Double(joint.confidence))))
                }
            }
        }
    }
}

struct BootSequenceView: View {
    @EnvironmentObject var app: AppState
    var body: some View {
        ZStack {
            Color.black.opacity(0.72)
            VStack(alignment: .leading, spacing: 10) {
                Text("JARVIS AR")
                    .font(.system(size: 28, weight: .light, design: .monospaced))
                    .foregroundStyle(HUDTheme.cyan)
                Text("SYSTEM INITIALIZING…")
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.6))
                ForEach(app.hud.bootLines) { line in
                    HStack {
                        Text(line.name.padding(toLength: 16, withPad: ".", startingAt: 0))
                            .font(.system(size: 12, design: .monospaced))
                        Text(line.ok ? "ONLINE" : "FAILED")
                            .foregroundStyle(line.ok ? HUDTheme.cyan : HUDTheme.warn)
                            .font(.system(size: 12, weight: .bold, design: .monospaced))
                    }
                }
            }
            .padding(28)
        }
        .ignoresSafeArea()
    }
}
