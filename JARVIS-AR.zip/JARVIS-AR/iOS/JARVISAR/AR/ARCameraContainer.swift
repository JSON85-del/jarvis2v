import SwiftUI
import RealityKit
import ARKit

struct ARCameraContainer: UIViewRepresentable {
    @EnvironmentObject var app: AppState

    func makeUIView(context: Context) -> ARView {
        let view = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: false)
        view.renderOptions.insert(.disableMotionBlur)
        view.environment.background = .cameraFeed()
        app.ar.attach(view)
        return view
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        app.ar.viewBounds = uiView.bounds.size
    }
}
