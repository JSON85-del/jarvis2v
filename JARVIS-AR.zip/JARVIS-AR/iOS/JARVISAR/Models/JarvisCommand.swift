import Foundation

struct JarvisCommand: Codable, Equatable {
    enum Intent: String, Codable, CaseIterable {
        case scanObject = "SCAN_OBJECT"
        case selectObject = "SELECT_OBJECT"
        case moveObject = "MOVE_AR_OBJECT"
        case rotateObject = "ROTATE_OBJECT"
        case scaleObject = "SCALE_OBJECT"
        case openPanel = "OPEN_PANEL"
        case closePanel = "CLOSE_PANEL"
        case search = "SEARCH"
        case readText = "READ_TEXT"
        case showInformation = "SHOW_INFORMATION"
        case changeMode = "CHANGE_MODE"
        case startNavigation = "START_NAVIGATION"
        case createARObject = "CREATE_AR_OBJECT"
        case remember = "REMEMBER"
    }

    var intent: Intent
    var target: String? = nil
    var direction: String? = nil
    var magnitude: Double? = nil
    var mode: String? = nil
    var query: String? = nil
    var objectType: String? = nil
}

struct JarvisTurnRequest: Codable {
    var userQuery: String
    var detectedObject: String?
    var ocrText: [String]
    var context: String
    var mode: String
    var availableActions: [String]
    var conversationId: String

    enum CodingKeys: String, CodingKey {
        case userQuery = "user_query"
        case detectedObject = "detected_object"
        case ocrText = "ocr_text"
        case context, mode
        case availableActions = "available_actions"
        case conversationId = "conversation_id"
    }
}

struct JarvisTurnResponse: Codable {
    var speech: String?
    var command: JarvisCommand?
    var conversationId: String?

    enum CodingKeys: String, CodingKey {
        case speech, command
        case conversationId = "conversation_id"
    }
}
