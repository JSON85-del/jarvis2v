import SwiftUI

struct RootView: View {
    @EnvironmentObject var app: AppState

    var body: some View {
        ZStack {
            ARCameraContainer()
                .ignoresSafeArea()
            HUDOverlayView()
            if app.phase != .ready && app.phase != .degraded {
                BootSequenceView()
            }
            if app.showSettings {
                SettingsView()
                    .transition(.move(edge: .trailing))
            }
        }
        .animation(.easeInOut(duration: 0.35), value: app.phase)
        .task { await app.bootstrap() }
    }
}
