import SwiftUI

@main
struct JARVISARApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
                .preferredColorScheme(.dark)
                .statusBarHidden(true)
        }
    }
}
