import Foundation
import Combine
import CoreGraphics

@MainActor
final class GestureManager: ObservableObject {
    let events = PassthroughSubject<GestureEvent, Never>()
    @Published var lastKind: GestureKind?
    @Published var selected = false

    private var pinchOn: [String: Bool] = [:]
    private var pinchEvidence: [String: Int] = [:]
    private var releaseEvidence: [String: Int] = [:]
    private var lastPinchTime: [String: TimeInterval] = [:]
    private var lastPalm: CGPoint?
    private var lastPalmTime: TimeInterval = 0
    private var grabActive = false
    private var lastTwoHandDistance: CGFloat?
    private var lastTwoHandAngle: CGFloat?

    func update(hands: [TrackedHand], settings: SettingsManager) {
        let live = hands.filter { !$0.isLost }
        let pinchThresh = settings.pinchThreshold
        let evidenceNeeded = settings.gestureEvidenceFrames

        for hand in live {
            let pinching = hand.pinchDistance < pinchThresh
            let was = pinchOn[hand.id] ?? false
            if pinching {
                pinchEvidence[hand.id, default: 0] += 1
                releaseEvidence[hand.id] = 0
                if !was && (pinchEvidence[hand.id] ?? 0) >= evidenceNeeded {
                    pinchOn[hand.id] = true
                    selected = true
                    let now = CACurrentMediaTime()
                    if let last = lastPinchTime[hand.id], now - last < 0.45 {
                        emit(.init(kind: .doublePinch, handID: hand.id, screenPoint: hand.indexTip))
                    } else {
                        emit(.init(kind: .pinch, handID: hand.id, screenPoint: hand.indexTip ?? hand.palm))
                    }
                    lastPinchTime[hand.id] = now
                }
            } else {
                releaseEvidence[hand.id, default: 0] += 1
                pinchEvidence[hand.id] = 0
                if was && (releaseEvidence[hand.id] ?? 0) >= evidenceNeeded {
                    pinchOn[hand.id] = false
                    selected = false
                    emit(.init(kind: .release, handID: hand.id, screenPoint: hand.indexTip))
                }
            }

            if isPointing(hand) && !pinching {
                emit(.init(kind: .point, handID: hand.id, screenPoint: hand.indexTip))
            }

            if isFist(hand) {
                if !grabActive {
                    grabActive = true
                    emit(.init(kind: .grab, handID: hand.id, screenPoint: hand.palm))
                } else if let palm = hand.palm {
                    emit(.init(kind: .move, handID: hand.id, screenPoint: palm))
                }
            } else if grabActive && !isFist(hand) {
                grabActive = false
            }

            if isOpenPalm(hand) {
                emit(.init(kind: .openPalm, handID: hand.id, screenPoint: hand.palm))
                if let last = lastPalm, let palm = hand.palm {
                    let dt = CACurrentMediaTime() - lastPalmTime
                    if dt > 0.02 && dt < 0.25 {
                        let dx = palm.x - last.x
                        let dy = palm.y - last.y
                        if hypot(dx, dy) > 80 {
                            let dir: String
                            if abs(dx) > abs(dy) { dir = dx > 0 ? "right" : "left" }
                            else { dir = dy > 0 ? "down" : "up" }
                            emit(.init(kind: .swipe, handID: hand.id, screenPoint: palm, swipeDirection: dir))
                        }
                    }
                }
                lastPalm = hand.palm
                lastPalmTime = CACurrentMediaTime()
            }
        }

        if live.count >= 2 {
            let a = live[0]
            let b = live[1]
            if let p1 = a.palm, let p2 = b.palm {
                let dist = hypot(p1.x - p2.x, p1.y - p2.y)
                if let prev = lastTwoHandDistance {
                    let scale = dist / max(prev, 1)
                    if abs(scale - 1) > 0.04 {
                        emit(.init(kind: .twoHandScale, screenPoint: mid(p1, p2), scale: scale))
                    }
                }
                lastTwoHandDistance = dist
                let angle = atan2(p2.y - p1.y, p2.x - p1.x)
                if let prev = lastTwoHandAngle {
                    emit(.init(kind: .twoHandRotate, screenPoint: mid(p1, p2), rotation: angle - prev))
                }
                lastTwoHandAngle = angle
            }
        } else {
            lastTwoHandDistance = nil
            lastTwoHandAngle = nil
        }
    }

    private func emit(_ event: GestureEvent) {
        lastKind = event.kind
        events.send(event)
    }

    private func isPointing(_ hand: TrackedHand) -> Bool {
        guard let index = hand.joints["indexTip"] ?? hand.joints.values.first(where: { $0.name.contains("indexTip") }) else {
            return hand.indexTip != nil && hand.pinchDistance > 40
        }
        return index.confidence > 0.4 && hand.pinchDistance > 36
    }

    private func isFist(_ hand: TrackedHand) -> Bool {
        let tips = ["indexTip", "middleTip", "ringTip", "littleTip"]
        let present = tips.compactMap { name in hand.joints.first { $0.key.contains(name) }?.value }
        guard let wrist = hand.wrist, present.count >= 3 else { return false }
        let avg = present.map { hypot($0.screenPoint.x - wrist.x, $0.screenPoint.y - wrist.y) }.reduce(0, +) / CGFloat(present.count)
        return avg < 70
    }

    private func isOpenPalm(_ hand: TrackedHand) -> Bool {
        let tips = ["indexTip", "middleTip", "ringTip", "littleTip"]
        let present = tips.compactMap { name in hand.joints.first { $0.key.contains(name) }?.value }
        guard let wrist = hand.wrist, present.count >= 3 else { return false }
        let avg = present.map { hypot($0.screenPoint.x - wrist.x, $0.screenPoint.y - wrist.y) }.reduce(0, +) / CGFloat(present.count)
        return avg > 110 && hand.pinchDistance > 40
    }

    private func mid(_ a: CGPoint, _ b: CGPoint) -> CGPoint {
        CGPoint(x: (a.x + b.x) / 2, y: (a.y + b.y) / 2)
    }
}
