import UIKit

final class HapticsManager {
    private let light = UIImpactFeedbackGenerator(style: .light)
    private let medium = UIImpactFeedbackGenerator(style: .medium)
    private let notify = UINotificationFeedbackGenerator()

    func hover() {
        guard SettingsManager.shared.hapticsEnabled else { return }
        light.impactOccurred(intensity: 0.55)
    }

    func select() {
        guard SettingsManager.shared.hapticsEnabled else { return }
        medium.impactOccurred()
    }

    func confirm() {
        guard SettingsManager.shared.hapticsEnabled else { return }
        notify.notificationOccurred(.success)
    }

    func error() {
        guard SettingsManager.shared.hapticsEnabled else { return }
        notify.notificationOccurred(.error)
    }
}
