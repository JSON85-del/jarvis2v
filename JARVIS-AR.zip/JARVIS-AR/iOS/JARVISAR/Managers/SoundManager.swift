import AVFoundation

enum JarvisSound {
    case startup, scan, lock, select, confirm, warning
}

final class SoundManager {
    private var players: [JarvisSound: AVAudioPlayer] = [:]

    func play(_ sound: JarvisSound) {
        guard SettingsManager.shared.soundEnabled else { return }
        // Procedural click via system sound as a dependency-free fallback.
        // Replace with bundled .wav files in Resources/Sounds when available.
        switch sound {
        case .warning:
            AudioServicesPlaySystemSound(1053)
        case .confirm, .select:
            AudioServicesPlaySystemSound(1104)
        case .lock, .scan:
            AudioServicesPlaySystemSound(1113)
        case .startup:
            AudioServicesPlaySystemSound(1025)
        }
    }
}

import AudioToolbox
