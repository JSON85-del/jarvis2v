import Foundation

struct ProductRecord: Codable, Identifiable, Equatable {
    var id: String
    var name: String
    var brand: String?
    var category: String?
    var size: String?
    var isSampleData: Bool
}

@MainActor
final class ProductManager: ObservableObject {
    @Published var lastMatches: [ProductRecord] = []
    private var settings: SettingsManager?
    private var sample: [ProductRecord] = [
        ProductRecord(id: "sample-cover-56", name: "Mattress Cover", brand: "Sample Brand", category: "Cover", size: "5 × 6", isSampleData: true)
    ]

    func configure(settings: SettingsManager) {
        self.settings = settings
    }

    func matchingLines(for label: String?) -> [String] {
        guard let label else { return [] }
        let hits = sample.filter { rec in
            rec.name.localizedCaseInsensitiveContains(label) ||
            (rec.category?.localizedCaseInsensitiveContains(label) ?? false) ||
            label.localizedCaseInsensitiveContains("mattress") && rec.category == "Cover"
        }
        lastMatches = hits
        return hits.map { rec in
            let flag = rec.isSampleData ? " (sample catalog, not live stock)" : ""
            return "\(rec.brand ?? "Unknown") · \(rec.name) · \(rec.size ?? "")\(flag)"
        }
    }

    func lookupRemote(query: String) async -> [ProductRecord] {
        guard let settings, let url = URL(string: settings.backendBaseURL + "/v1/products?q=\(query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query)") else {
            return sample
        }
        var req = URLRequest(url: url)
        req.setValue("Bearer \(settings.appAPIToken)", forHTTPHeaderField: "Authorization")
        do {
            let (data, response) = try await URLSession.shared.data(for: req)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { return sample }
            return try JSONDecoder().decode([ProductRecord].self, from: data)
        } catch {
            return sample
        }
    }
}
