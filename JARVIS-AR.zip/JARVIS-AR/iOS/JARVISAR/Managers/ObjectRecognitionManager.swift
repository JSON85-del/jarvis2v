import Foundation

@MainActor
final class ObjectRecognitionManager: ObservableObject {
    @Published var primaryLabel: String?
    @Published var confidence: Float = 0
    @Published var alternatives: [String] = []
    @Published var ocrLines: [String] = []
    @Published var isUncertain = true

    func applyClassification(_ result: ClassificationResult) {
        primaryLabel = humanize(result.label)
        confidence = result.confidence
        alternatives = result.alternatives.map(humanize)
        isUncertain = result.confidence < 0.45
    }

    func applyOCR(_ lines: [OCRLine]) {
        ocrLines = Array(lines.prefix(8).map(\.text))
    }

    var confidenceText: String {
        guard primaryLabel != nil else { return "No object lock" }
        if isUncertain { return "Object identification uncertain" }
        return String(format: "Confidence %.0f%%", confidence * 100)
    }

    var detailLines: [String] {
        var lines: [String] = []
        if let label = primaryLabel {
            lines.append("Class: \(label)")
        }
        if !alternatives.isEmpty {
            lines.append("Also possible: \(alternatives.dropFirst().prefix(3).joined(separator: ", "))")
        }
        if !ocrLines.isEmpty {
            lines.append("Text: \(ocrLines.prefix(3).joined(separator: " | "))")
        }
        return lines
    }

    func spokenSummary() -> String {
        guard let label = primaryLabel else {
            return "I don't have a confident identification yet."
        }
        if isUncertain {
            return "Object identification uncertain. It may be a \(label)."
        }
        var sentence = "I've identified this as a \(label)."
        if let brand = ocrLines.first {
            sentence += " Visible text includes \(brand)."
        }
        sentence += " I will not invent specifications that I cannot see or look up."
        return sentence
    }

    private func humanize(_ raw: String) -> String {
        raw.replacingOccurrences(of: "_", with: " ")
            .split(separator: ",")
            .first
            .map(String.init)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .capitalized ?? raw
    }
}
