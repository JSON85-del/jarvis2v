import Foundation
import Combine

@MainActor
final class SettingsManager: ObservableObject {
    static let shared = SettingsManager()

    @Published var backendBaseURL: String
    @Published var appAPIToken: String
    @Published var grokModel: String
    @Published var mhmBaseURL: String

    @Published var hudIntensity: Double = 0.85
    @Published var animationIntensity: Double = 0.7
    @Published var pinchThreshold: CGFloat = 28
    @Published var gestureEvidenceFrames: Int = 3
    @Published var soundEnabled = true
    @Published var hapticsEnabled = true
    @Published var reducedMotion = false
    @Published var highContrast = false
    @Published var alwaysListenAfterTap = true
    @Published var shareAIContext = true
    @Published var analyticsEnabled = false
    @Published var locationEnabled = false
    @Published var mhmModeEnabled = false

    init() {
        let plist = Self.loadPlist()
        backendBaseURL = plist["BackendBaseURL"] as? String ?? "http://127.0.0.1:8080"
        appAPIToken = plist["AppAPIToken"] as? String ?? "dev-token"
        grokModel = plist["GrokModel"] as? String ?? "grok-4.5"
        mhmBaseURL = plist["MHMBaseURL"] as? String ?? ""
    }

    private static func loadPlist() -> [String: Any] {
        guard let url = Bundle.main.url(forResource: "Config", withExtension: "plist"),
              let data = try? Data(contentsOf: url),
              let obj = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any]
        else { return [:] }
        return obj
    }
}
