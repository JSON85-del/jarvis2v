"""JARVIS AR secure proxy.

Holds the xAI API key. The iPhone only sends a session token.
"""

from __future__ import annotations

import json
import os
import time
import uuid
from collections import defaultdict
from typing import Any

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

XAI_API_KEY = os.environ.get("XAI_API_KEY", "")
APP_TOKEN = os.environ.get("JARVIS_API_TOKEN", "dev-token")
GROK_MODEL = os.environ.get("GROK_MODEL", "grok-4.5")
XAI_BASE = os.environ.get("XAI_BASE_URL", "https://api.x.ai/v1")

ALLOWED_INTENTS = {
    "SCAN_OBJECT",
    "SELECT_OBJECT",
    "MOVE_AR_OBJECT",
    "ROTATE_OBJECT",
    "SCALE_OBJECT",
    "OPEN_PANEL",
    "CLOSE_PANEL",
    "SEARCH",
    "READ_TEXT",
    "SHOW_INFORMATION",
    "CHANGE_MODE",
    "START_NAVIGATION",
    "CREATE_AR_OBJECT",
    "REMEMBER",
}

RATE_LIMIT = 30
WINDOW = 60.0
_hits: dict[str, list[float]] = defaultdict(list)

SYSTEM_PROMPT = """You are JARVIS, an on-device AR assistant speaking through an iPhone.
Be concise, calm, and precise. Never invent product specifications, stock counts, or hardware abilities.
The phone can: overlay AR entities, detect generic object classes, read visible text, track two hands in the camera image, and speak.
The phone cannot: project true holograms into empty air, move physical objects, see through walls, or control arbitrary devices.

When the user wants an app action, also return a JSON command using ONLY this schema:
{"intent":"ONE_OF_ALLOWED","target":null,"direction":null,"magnitude":null,"mode":null,"query":null,"objectType":null}

Allowed intents:
SCAN_OBJECT, SELECT_OBJECT, MOVE_AR_OBJECT, ROTATE_OBJECT, SCALE_OBJECT,
OPEN_PANEL, CLOSE_PANEL, SEARCH, READ_TEXT, SHOW_INFORMATION, CHANGE_MODE,
START_NAVIGATION, CREATE_AR_OBJECT, REMEMBER.

Reply as JSON only:
{"speech":"...","command":null_or_object}
"""


class TurnIn(BaseModel):
    user_query: str
    detected_object: str | None = None
    ocr_text: list[str] = Field(default_factory=list)
    context: str = "AR_CAMERA"
    mode: str = "default"
    available_actions: list[str] = Field(default_factory=list)
    conversation_id: str = ""


class CommandOut(BaseModel):
    intent: str
    target: str | None = None
    direction: str | None = None
    magnitude: float | None = None
    mode: str | None = None
    query: str | None = None
    objectType: str | None = None


class TurnOut(BaseModel):
    speech: str
    command: CommandOut | None = None
    conversation_id: str


app = FastAPI(title="JARVIS AR Proxy", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def auth(authorization: str | None = Header(default=None)) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = authorization.split(" ", 1)[1]
    if token != APP_TOKEN:
        raise HTTPException(401, "Invalid token")
    now = time.time()
    bucket = _hits[token]
    _hits[token] = [t for t in bucket if now - t < WINDOW]
    if len(_hits[token]) >= RATE_LIMIT:
        raise HTTPException(429, "Rate limited")
    _hits[token].append(now)
    return token


@app.get("/v1/health")
def health() -> dict[str, Any]:
    return {
        "ok": True,
        "grok_key_present": bool(XAI_API_KEY),
        "model": GROK_MODEL,
    }


@app.post("/v1/jarvis/turn", response_model=TurnOut)
async def turn(body: TurnIn, _: str = Depends(auth)) -> TurnOut:
    conversation_id = body.conversation_id or str(uuid.uuid4())
    if not XAI_API_KEY:
        return TurnOut(
            speech="Grok is not configured on the server. Local AR systems can still run.",
            command=heuristic_command(body.user_query),
            conversation_id=conversation_id,
        )

    user_block = {
        "question": body.user_query,
        "detected_object": body.detected_object,
        "ocr_text": body.ocr_text,
        "context": body.context,
        "mode": body.mode,
        "available_actions": [a for a in body.available_actions if a in ALLOWED_INTENTS],
    }
    payload = {
        "model": GROK_MODEL,
        "temperature": 0.4,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(user_block)},
        ],
    }
    try:
        async with httpx.AsyncClient(timeout=40.0) as client:
            res = await client.post(
                f"{XAI_BASE}/chat/completions",
                headers={
                    "Authorization": f"Bearer {XAI_API_KEY}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
        res.raise_for_status()
        content = res.json()["choices"][0]["message"]["content"]
        parsed = extract_json(content)
        speech = str(parsed.get("speech") or "").strip() or "Acknowledged."
        command = sanitize_command(parsed.get("command"))
        return TurnOut(speech=speech, command=command, conversation_id=conversation_id)
    except Exception:
        return TurnOut(
            speech="AI connection unavailable. Continuing with local systems.",
            command=heuristic_command(body.user_query),
            conversation_id=conversation_id,
        )


@app.get("/v1/products")
def products(q: str = Query(default=""), _: str = Depends(auth)) -> list[dict[str, Any]]:
    # Sample catalog only. Live inventory belongs on an MHM backend.
    sample = [
        {
            "id": "sample-cover-56",
            "name": "Mattress Cover",
            "brand": "Sample Brand",
            "category": "Cover",
            "size": "5 × 6",
            "isSampleData": True,
        }
    ]
    if not q:
        return sample
    qlow = q.lower()
    return [row for row in sample if qlow in json.dumps(row).lower()]


def extract_json(text: str) -> dict[str, Any]:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        try:
            data = json.loads(text[start : end + 1])
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            pass
    return {"speech": text, "command": None}


def sanitize_command(raw: Any) -> CommandOut | None:
    if not isinstance(raw, dict):
        return None
    intent = raw.get("intent")
    if intent not in ALLOWED_INTENTS:
        return None
    return CommandOut(
        intent=intent,
        target=_str(raw.get("target")),
        direction=_str(raw.get("direction")),
        magnitude=_float(raw.get("magnitude")),
        mode=_str(raw.get("mode")),
        query=_str(raw.get("query")),
        objectType=_str(raw.get("objectType")),
    )


def heuristic_command(query: str) -> CommandOut | None:
    q = query.lower()
    if "scan" in q or "identify" in q or "what am i looking" in q:
        return CommandOut(intent="SCAN_OBJECT")
    if "remember" in q:
        return CommandOut(intent="REMEMBER", query=query)
    if "read" in q:
        return CommandOut(intent="READ_TEXT")
    return None


def _str(v: Any) -> str | None:
    return str(v) if v is not None and str(v) not in {"", "null", "None"} else None


def _float(v: Any) -> float | None:
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None
